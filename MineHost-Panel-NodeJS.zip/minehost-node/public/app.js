const $ = s => document.querySelector(s);
let mode = "login", currentUser = null;
async function api(url, options={}) {
  const r = await fetch("/api"+url,{credentials:"same-origin",headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
  const data = await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error || `Erro HTTP ${r.status}`);
  return data;
}
function showAuth(){ $("#auth").hidden=false;$("#app").hidden=true; }
function showApp(){ $("#auth").hidden=true;$("#app").hidden=false;$("#hello").textContent=`Olá, ${currentUser.email}`;$("#admin").hidden=currentUser.role!=="admin";loadServers();if(currentUser.role==="admin"){loadOverview();loadAdminRequests();} }
$("#loginTab").onclick=()=>{mode="login";$("#loginTab").classList.add("active");$("#registerTab").classList.remove("active");$("#authSubmit").textContent="Entrar";};
$("#registerTab").onclick=()=>{mode="register";$("#registerTab").classList.add("active");$("#loginTab").classList.remove("active");$("#authSubmit").textContent="Criar conta";};
$("#authForm").onsubmit=async e=>{e.preventDefault();$("#authError").textContent="";const f=new FormData(e.target);try{const d=await api(`/auth/${mode}`,{method:"POST",body:JSON.stringify(Object.fromEntries(f))});currentUser=d.user;showApp();}catch(err){$("#authError").textContent=err.message;}};
$("#logout").onclick=async()=>{await api("/auth/logout",{method:"POST"});currentUser=null;showAuth();};
async function loadServers(){try{const d=await api("/servers");$("#serverRows").innerHTML=d.servers.map(s=>`<tr><td>${esc(s.name)}</td><td>${esc(s.edition)}</td><td>${s.ram_mb} MB RAM · ${s.disk_mb} MB</td><td><span class="status ${esc(s.status)}">${esc(s.status)}</span></td><td>${new Date(s.created_at).toLocaleDateString("pt-BR")}</td></tr>`).join("")||'<tr><td colspan="5">Nenhuma solicitação ainda.</td></tr>';}catch(e){console.error(e);}}
$("#refresh").onclick=loadServers;
$("#serverForm").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target),d=Object.fromEntries(f);d.ram_mb=Number(d.ram_mb);d.disk_mb=Number(d.disk_mb);try{const r=await api("/servers",{method:"POST",body:JSON.stringify(d)});$("#serverMessage").textContent=r.message; e.target.reset();loadServers();}catch(err){$("#serverMessage").textContent=err.message;}};
$("#matrixCode").onclick=async()=>{try{const d=await api("/matrix/link-code",{method:"POST",body:"{}"});$("#matrixResult").textContent=d.code;}catch(e){$("#matrixResult").textContent=e.message;}};
async function loadOverview(){try{const d=await api("/admin/overview");$("#adminStats").hidden=false;$("#adminStats").innerHTML=Object.entries({Usuários:d.users,Servidores:d.servers,Pendentes:d.pending,Provedores:d.providers,Máquinas:d.nodes}).map(([k,v])=>`<div class="stat"><b>${v}</b><span>${k}</span></div>`).join("");}catch(e){}}
async function loadAdminRequests(){try{const d=await api("/admin/requests");$("#adminRows").innerHTML=d.requests.map(s=>`<tr><td>${esc(s.email)}</td><td>${esc(s.name)}</td><td>${esc(s.edition)}</td><td>${esc(s.status)}</td><td><select data-id="${s.id}" class="statusSelect"><option>pending</option><option>approved</option><option>rejected</option><option>active</option><option>suspended</option></select></td></tr>`).join("")||'<tr><td colspan="5">Sem solicitações.</td></tr>';document.querySelectorAll(".statusSelect").forEach(el=>{el.value=el.parentElement.previousElementSibling.textContent;el.onchange=async()=>{try{await api(`/admin/requests/${el.dataset.id}`,{method:"PATCH",body:JSON.stringify({status:el.value})});$("#adminMessage").textContent="Status atualizado.";}catch(e){$("#adminMessage").textContent=e.message;}};});}catch(e){}}
$("#providerForm").onsubmit=async e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));d.enabled=false;try{await api("/admin/providers",{method:"POST",body:JSON.stringify(d)});$("#adminMessage").textContent="Provedor registrado. Adaptador de provisionamento ainda precisa ser configurado.";loadOverview();e.target.reset();}catch(x){$("#adminMessage").textContent=x.message;}};
$("#nodeForm").onsubmit=async e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));d.capacity_ram_mb=Number(d.capacity_ram_mb);d.capacity_disk_mb=Number(d.capacity_disk_mb);d.enabled=false;try{await api("/admin/nodes",{method:"POST",body:JSON.stringify(d)});$("#adminMessage").textContent="Máquina registrada (sem agente instalado).";loadOverview();e.target.reset();}catch(x){$("#adminMessage").textContent=x.message;}};
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
(async()=>{try{const d=await api("/me");currentUser=d.user;showApp();}catch{showAuth();}})();
