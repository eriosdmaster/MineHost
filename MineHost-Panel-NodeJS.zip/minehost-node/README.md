# MineHost Panel

Painel web Node.js para hospedagem de servidores Minecraft Java e Bedrock, com API, PostgreSQL e integração Matrix por Client-Server API.

## Importante sobre hospedagem sem VPS

Este projeto roda como uma aplicação Node.js persistente em uma hospedagem que suporte:
- Node.js 20 ou superior;
- processo web Node.js mantido ativo;
- variáveis de ambiente;
- conexão de saída HTTPS;
- PostgreSQL externo ou PostgreSQL fornecido pela hospedagem.

Não requer cPanel, Docker ou acesso root. Não é compatível com hospedagens que só executam scripts Node por poucos segundos. O bot Matrix usa long-polling e precisa que o processo permaneça ativo.

O painel não consegue criar servidores em máquinas de terceiros por conta própria. Para provisionamento real, é necessário configurar uma API oficial de um provedor e implementar/ativar seu adaptador autorizado. Não informe credenciais de painel de terceiros a este projeto sem verificar as permissões.

## Deploy genérico

1. Crie um banco PostgreSQL na hospedagem ou em serviço gerenciado.
2. Envie o conteúdo deste ZIP para o serviço Node.js ou conecte o repositório.
3. Configure a versão Node.js para 20+.
4. Configure as variáveis de ambiente conforme `.env.example`.
5. Comando de instalação: `npm install`
6. Comando de inicialização: `npm start`
7. Configure `DATABASE_URL`, `JWT_SECRET`, `ADMIN_EMAIL` e `ADMIN_PASSWORD`.
8. Abra o domínio da aplicação. O banco e o administrador inicial são preparados automaticamente.

Se a hospedagem exigir porta fixa, configure `PORT` conforme a documentação dela. A aplicação usa `process.env.PORT`.

## Primeiro acesso

Use o e-mail e a senha definidos em `ADMIN_EMAIL` e `ADMIN_PASSWORD`. O usuário administrador é criado no primeiro boot, caso ainda não exista. Altere a senha no ambiente e nunca compartilhe o `.env`.

## Matrix / Element X

Crie um usuário/bot Matrix e configure:
- `MATRIX_HOMESERVER`
- `MATRIX_ACCESS_TOKEN`
- `MATRIX_BOT_USER`

Convide o bot para uma sala e envie `!help`. O bot oferece `!link CODIGO`, `!servers` e `!help`. O código de vínculo é gerado no painel em **Conta > Vincular Matrix**.

Este MVP usa mensagens Matrix não criptografadas (sem E2EE). Salas com criptografia ativada não são suportadas por este conector. Não use o bot em salas privadas sensíveis até implementar armazenamento criptográfico e suporte E2EE.

## Funcionalidades implementadas

- Cadastro e login com hash de senha;
- JWT em cookie HttpOnly;
- painel cliente;
- painel administrativo básico;
- criação de solicitações de servidor Java/Bedrock;
- lista e estado das solicitações;
- cadastro administrativo de provedores e máquinas;
- códigos de vínculo Matrix;
- bot Matrix com long-polling e comandos básicos;
- PostgreSQL e migrações automáticas;
- rate limit, Helmet, validação e consultas parametrizadas.

## Limitações deliberadas

- Solicitações de servidores são registradas como `pending`; isso não significa que um servidor foi provisionado.
- A criação real, console, arquivos, energia e backups dependem do adaptador/API oficial do provedor escolhido.
- O cadastro de nós é administrativo e não instala agente. Hospedagem compartilhada Node não deve ser usada como agente Docker.
- Não há suporte E2EE Matrix nesta versão.
- Configure HTTPS no domínio e backups do PostgreSQL no provedor.

## Estrutura

- `src/index.js`: servidor web.
- `src/db.js`: PostgreSQL e schema.
- `src/auth.js`: autenticação.
- `src/routes.js`: API.
- `src/matrix.js`: integração Matrix.
- `public/`: interface web.
