import "dotenv/config";
import express from "express";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import path from "node:path";
import { fileURLToPath } from "node:url";
import routes from "./routes.js";
import { initDb, pool } from "./db.js";
import { startMatrixBot } from "./matrix.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "100kb" }));
app.use(cookieParser());
app.use("/api", routes);
app.use(express.static(path.join(__dirname, "../public")));
app.get("/health", (_req, res) => res.json({ ok: true, service: "minehost-panel" }));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "../public/index.html")));

const port = Number(process.env.PORT || 3000);
await initDb();
const server = app.listen(port, "0.0.0.0", () => console.log(`MineHost Panel ouvindo na porta ${port}`));
startMatrixBot().catch(e => console.error("Matrix bot encerrou:", e));

const shutdown = async () => {
  server.close();
  await pool.end();
  process.exit(0);
};
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
