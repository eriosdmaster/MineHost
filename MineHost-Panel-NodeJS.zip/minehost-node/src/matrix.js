import { query } from "./db.js";

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const hs = () => (process.env.MATRIX_HOMESERVER || "https://matrix.org").replace(/\/+$/, "");
const token = () => process.env.MATRIX_ACCESS_TOKEN;

async function matrixRequest(path, options = {}) {
  const response = await fetch(`${hs()}/_matrix/client/v3${path}`, {
    ...options,
    headers: { Authorization: `Bearer ${token()}`, "Content-Type": "application/json", ...(options.headers || {}) }
  });
  if (!response.ok) throw new Error(`Matrix HTTP ${response.status}: ${await response.text()}`);
  return response.status === 204 ? null : response.json();
}

async function send(roomId, body) {
  const txn = `${Date.now()}${Math.random().toString(16).slice(2)}`;
  await matrixRequest(`/rooms/${encodeURIComponent(roomId)}/send/m.room.message/${txn}`, {
    method: "PUT", body: JSON.stringify({ msgtype: "m.text", body })
  });
}

async function handleEvent(event) {
  if (event.type !== "m.room.message" || event.sender === process.env.MATRIX_BOT_USER) return;
  const body = event.content?.body;
  if (typeof body !== "string" || !body.startsWith("!")) return;
  const [command, arg] = body.trim().split(/\s+/, 2);
  const room = event.room_id;
  try {
    if (command === "!help") {
      await send(room, "MineHost Bot\n!help — ajuda\n!link CODIGO — vincula sua conta do painel\n!servers — lista suas solicitações");
    } else if (command === "!link" && arg) {
      const r = await query("UPDATE users SET matrix_user=$1,matrix_link_code=NULL WHERE matrix_link_code=$2 RETURNING email",
        [event.sender, arg.toUpperCase()]);
      await send(room, r.rowCount ? `Conta ${r.rows[0].email} vinculada com sucesso.` : "Código inválido ou expirado. Gere outro pelo painel.");
    } else if (command === "!servers") {
      const u = await query("SELECT id FROM users WHERE matrix_user=$1", [event.sender]);
      if (!u.rowCount) return send(room, "Sua conta ainda não está vinculada. Gere um código em Conta > Vincular Matrix.");
      const s = await query("SELECT name,edition,status FROM server_requests WHERE user_id=$1 ORDER BY id DESC LIMIT 10", [u.rows[0].id]);
      await send(room, s.rowCount ? s.rows.map(x => `${x.name} (${x.edition}) — ${x.status}`).join("\n") : "Você ainda não tem solicitações.");
    }
  } catch (e) {
    console.error("Erro no comando Matrix:", e.message);
    await send(room, "Ocorreu um erro ao processar o comando.");
  }
}

export async function startMatrixBot() {
  if (!token()) {
    console.log("Matrix bot desativado: MATRIX_ACCESS_TOKEN não configurado.");
    return;
  }
  let since;
  console.log("Matrix bot iniciado (E2EE não suportado nesta versão).");
  while (true) {
    try {
      const params = new URLSearchParams({ timeout: process.env.MATRIX_POLL_TIMEOUT_MS || "30000", ...(since ? { since } : {}) });
      const data = await matrixRequest(`/sync?${params.toString()}`);
      since = data.next_batch;
      for (const room of Object.values(data.rooms?.join || {})) {
        for (const event of room.timeline?.events || []) await handleEvent(event);
      }
    } catch (e) {
      console.error("Matrix sync:", e.message);
      await sleep(5000);
    }
  }
}
