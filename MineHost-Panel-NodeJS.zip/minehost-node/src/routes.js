import express from "express";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import { query } from "./db.js";
import { hashPassword, verifyPassword, signToken, requireAuth, requireAdmin } from "./auth.js";
import crypto from "node:crypto";

const router = express.Router();
const authLimit = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });

router.post("/auth/register", authLimit, async (req, res) => {
  const parsed = z.object({
    email: z.string().email().max(190),
    password: z.string().min(10).max(100)
  }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Informe e-mail válido e senha de 10 a 100 caracteres" });
  try {
    const hash = await hashPassword(parsed.data.password);
    const result = await query(
      "INSERT INTO users(email,password_hash) VALUES($1,$2) RETURNING id,email,role",
      [parsed.data.email.toLowerCase(), hash]
    );
    const user = result.rows[0];
    res.cookie("minehost_token", signToken(user), { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", maxAge: 7*24*60*60*1000 });
    res.status(201).json({ user });
  } catch (e) {
    if (e.code === "23505") return res.status(409).json({ error: "Este e-mail já está cadastrado" });
    throw e;
  }
});

router.post("/auth/login", authLimit, async (req, res) => {
  const parsed = z.object({ email: z.string().email(), password: z.string().min(1) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Dados inválidos" });
  const result = await query("SELECT * FROM users WHERE lower(email)=lower($1)", [parsed.data.email]);
  if (!result.rowCount || !(await verifyPassword(parsed.data.password, result.rows[0].password_hash))) {
    return res.status(401).json({ error: "E-mail ou senha incorretos" });
  }
  const u = result.rows[0];
  res.cookie("minehost_token", signToken(u), { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", maxAge: 7*24*60*60*1000 });
  res.json({ user: { id: u.id, email: u.email, role: u.role } });
});

router.post("/auth/logout", (_req, res) => {
  res.clearCookie("minehost_token", { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" });
  res.json({ ok: true });
});

router.get("/me", requireAuth, (req, res) => res.json({ user: req.user }));

router.get("/servers", requireAuth, async (req, res) => {
  const result = await query(
    "SELECT id,name,edition,software,ram_mb,disk_mb,status,created_at FROM server_requests WHERE user_id=$1 ORDER BY id DESC",
    [req.user.id]
  );
  res.json({ servers: result.rows });
});

router.post("/servers", requireAuth, async (req, res) => {
  const parsed = z.object({
    name: z.string().trim().min(3).max(32).regex(/^[a-zA-Z0-9_-]+$/),
    edition: z.enum(["java","bedrock"]),
    software: z.string().trim().min(2).max(40),
    ram_mb: z.number().int().min(512).max(16384),
    disk_mb: z.number().int().min(1024).max(102400)
  }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Dados inválidos. Nome: 3-32 caracteres; RAM: 512-16384 MB; disco: 1024-102400 MB." });

  const count = await query("SELECT COUNT(*)::int AS n FROM server_requests WHERE user_id=$1 AND status IN ('pending','active')", [req.user.id]);
  if (count.rows[0].n >= 3) return res.status(429).json({ error: "Limite de 3 solicitações/servidores por usuário" });

  const { name, edition, software, ram_mb, disk_mb } = parsed.data;
  const result = await query(
    `INSERT INTO server_requests(user_id,name,edition,software,ram_mb,disk_mb)
     VALUES($1,$2,$3,$4,$5,$6)
     RETURNING id,name,edition,software,ram_mb,disk_mb,status,created_at`,
    [req.user.id,name,edition,software,ram_mb,disk_mb]
  );
  await query("INSERT INTO audit_logs(actor_id,action,details) VALUES($1,'server.request.created',$2)", [req.user.id, JSON.stringify({ server_id: result.rows[0].id })]);
  res.status(201).json({ server: result.rows[0], message: "Solicitação registrada. A criação real depende de um provedor autorizado configurado pelo administrador." });
});

router.post("/matrix/link-code", requireAuth, async (req, res) => {
  const code = crypto.randomBytes(4).toString("hex").toUpperCase();
  await query("UPDATE users SET matrix_link_code=$1 WHERE id=$2", [code, req.user.id]);
  res.json({ code, instruction: `Envie ao bot Matrix: !link ${code}` });
});

router.get("/admin/overview", requireAuth, requireAdmin, async (_req, res) => {
  const [users, servers, pending, providers, nodes] = await Promise.all([
    query("SELECT COUNT(*)::int n FROM users"),
    query("SELECT COUNT(*)::int n FROM server_requests"),
    query("SELECT COUNT(*)::int n FROM server_requests WHERE status='pending'"),
    query("SELECT COUNT(*)::int n FROM providers"),
    query("SELECT COUNT(*)::int n FROM nodes")
  ]);
  res.json({ users: users.rows[0].n, servers: servers.rows[0].n, pending: pending.rows[0].n, providers: providers.rows[0].n, nodes: nodes.rows[0].n });
});

router.get("/admin/requests", requireAuth, requireAdmin, async (_req, res) => {
  const r = await query(
    `SELECT s.*,u.email FROM server_requests s JOIN users u ON u.id=s.user_id ORDER BY s.created_at DESC LIMIT 200`
  );
  res.json({ requests: r.rows });
});

router.patch("/admin/requests/:id", requireAuth, requireAdmin, async (req, res) => {
  const parsed = z.object({ status: z.enum(["pending","approved","rejected","active","suspended"]) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Status inválido" });
  const r = await query("UPDATE server_requests SET status=$1 WHERE id=$2 RETURNING id,status", [parsed.data.status, req.params.id]);
  if (!r.rowCount) return res.status(404).json({ error: "Solicitação não encontrada" });
  await query("INSERT INTO audit_logs(actor_id,action,details) VALUES($1,'server.request.updated',$2)", [req.user.id, JSON.stringify({ request_id: req.params.id, status: parsed.data.status })]);
  res.json({ request: r.rows[0] });
});

router.get("/admin/providers", requireAuth, requireAdmin, async (_req, res) => {
  const r = await query("SELECT * FROM providers ORDER BY id DESC");
  res.json({ providers: r.rows });
});

router.post("/admin/providers", requireAuth, requireAdmin, async (req, res) => {
  const p = z.object({
    name: z.string().min(2).max(100),
    kind: z.enum(["official_api","managed_node"]),
    base_url: z.string().url().optional().or(z.literal("")),
    enabled: z.boolean().default(false),
    notes: z.string().max(1000).optional()
  }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: "Dados de provedor inválidos" });
  const d = p.data;
  const r = await query("INSERT INTO providers(name,kind,base_url,enabled,notes) VALUES($1,$2,$3,$4,$5) RETURNING *",
    [d.name,d.kind,d.base_url || null,d.enabled,d.notes || null]);
  res.status(201).json({ provider: r.rows[0] });
});

router.get("/admin/nodes", requireAuth, requireAdmin, async (_req, res) => {
  const r = await query("SELECT n.*,p.name provider_name FROM nodes n LEFT JOIN providers p ON p.id=n.provider_id ORDER BY n.id DESC");
  res.json({ nodes: r.rows });
});

router.post("/admin/nodes", requireAuth, requireAdmin, async (req, res) => {
  const p = z.object({
    name: z.string().min(2).max(100),
    provider_id: z.number().int().positive().nullable().optional(),
    location: z.string().max(120).optional(),
    capacity_ram_mb: z.number().int().min(0).max(1048576),
    capacity_disk_mb: z.number().int().min(0).max(10485760),
    enabled: z.boolean().default(false)
  }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: "Dados de máquina inválidos" });
  const d = p.data;
  const r = await query("INSERT INTO nodes(name,provider_id,location,capacity_ram_mb,capacity_disk_mb,enabled) VALUES($1,$2,$3,$4,$5,$6) RETURNING *",
    [d.name,d.provider_id || null,d.location || null,d.capacity_ram_mb,d.capacity_disk_mb,d.enabled]);
  res.status(201).json({ node: r.rows[0] });
});

export default router;
